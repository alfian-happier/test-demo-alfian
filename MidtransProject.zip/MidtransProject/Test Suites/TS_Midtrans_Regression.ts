<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Regression Suite - Demo Midtrans Full Flow</description>
   <name>TS_Midtrans_Regression</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testBrowserType>Chrome</testBrowserType>
   <testCaseLink>
      <guid>tc001-midtrans-fullflow-creditcard</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC001_Midtrans_FullFlow</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
