# 🧪 MidtransProject — Katalon Studio Automation

Automation test untuk **https://demo.midtrans.com**
Flow: **Buy → Isi Form → Submit → Cancel → Checkout → Credit Card Payment**

---

## 📁 Struktur Project

```
MidtransProject/
├── MidtransProject.prj                  ← File project utama (buka ini di Katalon)
├── Test Cases/
│   ├── TC001_Midtrans_FullFlow.groovy   ← Script utama
│   └── TC001_Midtrans_FullFlow.tc       ← Metadata test case
├── Test Suites/
│   └── TS_Midtrans_Regression.ts        ← Suite untuk run semua TC
├── Profiles/
│   └── default.glbl                     ← Global variables (URL, card data, OTP)
├── evidence/                            ← Screenshot otomatis tersimpan di sini
└── .settings/
    └── *.xml                            ← Konfigurasi eksekusi
```

---

## 🚀 Cara Run

### 1. Buka Project
- Buka **Katalon Studio**
- **File → Open Project** → pilih file `MidtransProject.prj`

### 2. Run Test Case
- Di panel kiri, expand **Test Cases**
- Klik kanan `TC001_Midtrans_FullFlow` → **Run** → pilih **Chrome**

### 3. Run via Test Suite
- Expand **Test Suites**
- Klik kanan `TS_Midtrans_Regression` → **Run** → pilih **Chrome**

---

## 📸 Screenshot Evidence

Screenshot otomatis tersimpan di folder `/evidence` dengan format:
```
evidence/
├── 01_homepage_20260606_143010.png
├── 02_after_buy_click_20260606_143015.png
├── 03_form_filled_20260606_143022.png
├── 04_after_submit_20260606_143028.png
├── 05_before_cancel_20260606_143031.png
├── 05_after_cancel_20260606_143034.png
├── 06_after_checkout_20260606_143038.png
├── 07_snap_popup_visible_20260606_143045.png
├── 08_credit_card_selected_20260606_143050.png
├── 09_card_data_filled_20260606_143055.png
├── 10_after_pay_click_20260606_143100.png
├── 11_otp_page_20260606_143108.png
├── 11_otp_submitted_20260606_143112.png
└── 12_PAYMENT_SUCCESS_20260606_143120.png
```

---

## 🃏 Data Kartu Kredit Sandbox

| Field       | Value                  |
|-------------|------------------------|
| Card Number | `4811 1111 1111 1114`  |
| Expiry      | `01/25`                |
| CVV         | `123`                  |
| OTP         | `112233`               |

---

## ⚙️ Kebutuhan Sistem

| Kebutuhan      | Versi / Keterangan              |
|----------------|---------------------------------|
| Katalon Studio | Free, versi terbaru             |
| Java JDK       | 8 atau 11                       |
| Google Chrome  | Terbaru                         |
| ChromeDriver   | Harus sama dengan versi Chrome  |
| Internet       | Untuk akses demo.midtrans.com   |

---

## ❗ Troubleshooting

| Problem | Solusi |
|---|---|
| Element not found | Buka devtools, inspect XPath yang gagal |
| Snap iframe timeout | Naikkan timeout di `waitForElementVisible` jadi 20 |
| Screenshot folder error | Pastikan ada akses write ke folder project |
| ChromeDriver error | Download versi ChromeDriver sesuai Chrome kamu |
