// TC001 - Full Flow: Buy → Isi Form → Submit → Cancel → Checkout → Credit Card Payment
// Screenshot disimpan di: /evidence/TC_Midtrans_[timestamp]/
// Card: 4811 1111 1111 1114 | Expiry: 01/25 | CVV: 123 | OTP: 112233

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.configuration.RunConfiguration

// Helper: buat TestObject dari XPath langsung
def x(String xpath) {
    TestObject obj = new TestObject()
    obj.addProperty('xpath', ConditionType.EQUALS, xpath)
    return obj
}

// Helper: screenshot dengan nama step otomatis
// File disimpan di folder /evidence di dalam project directory
def ss(String stepName) {
    String timestamp = new Date().format('yyyyMMdd_HHmmss')
    String folder    = RunConfiguration.getProjectDir() + '/evidence'
    new File(folder).mkdirs()
    String filePath  = "${folder}/${stepName}_${timestamp}.png"
    WebUI.takeScreenshot(filePath)
    WebUI.comment("📸 Screenshot: ${filePath}")
}

// ═══════════════════════════════════════════════════════════
// STEP 1 — Buka browser
// ═══════════════════════════════════════════════════════════
WebUI.openBrowser('')
WebUI.maximizeWindow()
WebUI.navigateToUrl('https://demo.midtrans.com')
WebUI.waitForPageLoad(10)
ss('01_homepage')

// ═══════════════════════════════════════════════════════════
// STEP 2 — Klik BUY
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//a[contains(@class,'btn') and contains(@href,'checkout')]"), 10)
WebUI.click(
    x("//a[contains(@class,'btn') and contains(@href,'checkout')]"))
WebUI.waitForPageLoad(10)
ss('02_after_buy_click')

// ═══════════════════════════════════════════════════════════
// STEP 3 — Isi semua field form
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(x("//input[@name='order[first_name]']"), 10)
WebUI.setText(x("//input[@name='order[first_name]']"),  'Budi')
WebUI.setText(x("//input[@name='order[last_name]']"),   'Santoso')
WebUI.setText(x("//input[@name='order[email]']"),       'budi.santoso@example.com')
WebUI.setText(x("//input[@name='order[phone]']"),       '081234567890')
WebUI.setText(x("//input[@name='order[address]']"),     'Jl. Sudirman No. 1')
WebUI.setText(x("//input[@name='order[city]']"),        'Jakarta')
WebUI.setText(x("//input[@name='order[postal_code]']"), '10220')
ss('03_form_filled')

// ═══════════════════════════════════════════════════════════
// STEP 4 — Klik Submit
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//input[@type='submit'] | //button[@type='submit']"), 10)
WebUI.click(
    x("//input[@type='submit'] | //button[@type='submit']"))
WebUI.waitForPageLoad(10)
ss('04_after_submit')

// ═══════════════════════════════════════════════════════════
// STEP 5 — Klik Cancel
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//a[contains(text(),'Cancel') or contains(text(),'Batal')] | //button[contains(text(),'Cancel') or contains(text(),'Batal')]"), 10)
ss('05_before_cancel')
WebUI.click(
    x("//a[contains(text(),'Cancel') or contains(text(),'Batal')] | //button[contains(text(),'Cancel') or contains(text(),'Batal')]"))
WebUI.waitForPageLoad(10)
ss('05_after_cancel')

// ═══════════════════════════════════════════════════════════
// STEP 6 — Klik Checkout
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//a[contains(text(),'Checkout') or contains(@href,'checkout')] | //button[contains(text(),'Checkout')]"), 10)
WebUI.click(
    x("//a[contains(text(),'Checkout') or contains(@href,'checkout')] | //button[contains(text(),'Checkout')]"))
WebUI.waitForPageLoad(10)
ss('06_after_checkout')

// ═══════════════════════════════════════════════════════════
// STEP 7 — Switch ke Snap iframe
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//iframe[contains(@src,'midtrans')]"), 15)
ss('07_snap_popup_visible')
WebUI.switchToFrame(
    x("//iframe[contains(@src,'midtrans')]"), 10)

// ═══════════════════════════════════════════════════════════
// STEP 8 — Pilih Credit Card
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//*[@data-payment-type='credit_card']"), 15)
WebUI.click(x("//*[@data-payment-type='credit_card']"))
ss('08_credit_card_selected')

// ═══════════════════════════════════════════════════════════
// STEP 9 — Isi data kartu kredit
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(x("//input[@id='card-number']"), 10)
WebUI.setText(x("//input[@id='card-number']"), '4811111111111114')
WebUI.setText(x("//input[@id='card-expiry']"), '0125')
WebUI.setText(x("//input[@id='card-cvv']"),    '123')
ss('09_card_data_filled')

// ═══════════════════════════════════════════════════════════
// STEP 10 — Klik Pay Now
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(
    x("//button[contains(@class,'pay-button')]"), 10)
WebUI.click(x("//button[contains(@class,'pay-button')]"))
ss('10_after_pay_click')

// ═══════════════════════════════════════════════════════════
// STEP 11 — Input OTP
// ═══════════════════════════════════════════════════════════
WebUI.waitForElementVisible(x("//input[@id='otp']"), 15)
ss('11_otp_page')
WebUI.setText(x("//input[@id='otp']"), '112233')
WebUI.click(x("//button[@type='submit']"))
ss('11_otp_submitted')

// ═══════════════════════════════════════════════════════════
// STEP 12 — Verifikasi & screenshot final sukses
// ═══════════════════════════════════════════════════════════
WebUI.switchToDefaultContent()
WebUI.waitForElementVisible(
    x("//*[contains(@class,'alert-success') or contains(@class,'order-success')]"), 20)
ss('12_PAYMENT_SUCCESS')
String result = WebUI.getText(
    x("//*[contains(@class,'alert-success') or contains(@class,'order-success')]"))
WebUI.verifyMatch(result, '(?i).*(success|berhasil|confirmed).*', true)
WebUI.comment('>> Pembayaran sukses: ' + result)

WebUI.closeBrowser()
